package pl.gisexpert.invoice.model;

public class PdfDocument {
	private byte [] data;

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

}
