package pl.gisexpert.invoice.model;

public class DocumentModel {

}
